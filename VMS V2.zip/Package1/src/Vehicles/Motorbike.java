
package Vehicles;
    
import java.util.ArrayList;
import java.util.List;

        

     public class Motorbike extends Vehicles {
        
         
            List<String> Options = new ArrayList<>();
        
            
            
       public Motorbike(String Make, String Model, int Year, Gearboxtype Gearbox, 
               Colour Colour, int Mileage, String VIN) {
           super(Make, Model, Year, Gearbox, Colour, Mileage, VIN);
       }

    
     }

     
