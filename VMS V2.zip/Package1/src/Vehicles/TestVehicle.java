//
//*****This was used for a previous version of code*****




////package Vehicles;
//
//public class TestVehicle {
//    
//    public static void main(String[] args) {
//        
//        //Cars
//        Car Micra = new Estate("Nissan", "Micra", 1994, Gearboxtype.Manual, Colour.Black, 45000, "K112564") ;
//                // Micra.AddSatNav(Micra);
//                // Micra.AddSatNav(Micra);
//                
//                       
//        Car Mazda = new SUV("Mazda", "3 MPS", 2010, Gearboxtype.Manual, Colour.Red, 95000, "MZD12542");
//             //Mazda.AddAWD(Mazda);
//             // Mazda.AddAWD(Mazda);
//                 //Mazda.AddOptions("Sat Nav");
//                 //Mazda.AddOptions("Tow Bar");
//               
//        Car Porsche = new Saloon("Porsche", "Boxster", 2000, Gearboxtype.Automatic, Colour.White, 5000, "POR5433");
//              //   Porsche.AddOptions("Sat Nav");
//                // Porsche.AddOptions("Parking Sensors");
//                // Porsche.AddOptions("Tow Bar");
//                 //Porsche.AddOptions("Roof Rack");
//         
//        //Bikes
//        Motorbike Honda = new Motorbike("Honda", "CBR1200", 2021, Gearboxtype.Automatic, Colour.Green, 500, "CBR125523");
//                 //Honda.AddOptions("Luggage Box");
//                 //Honda.RemoveOptions("Luggage Box");
//                 
//        Motorbike Suzuki = new Motorbike("Suzuki", "MB350", 2020, Gearboxtype.Automatic, Colour.Blue, 5100, "MB3502315");
//                 
// 
//        Vehicles [] Vehicle = new Vehicles[5];
//         
//         Vehicle [0] = Micra;
//         Vehicle [1] = Mazda;
//         Vehicle [2] = Porsche;
//         Vehicle [3] = Honda;
//         Vehicle [4] = Suzuki;
//
//         }
//
//    }
//    
//
