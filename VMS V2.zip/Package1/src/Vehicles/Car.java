
package Vehicles;

import java.util.ArrayList;
import java.util.List;

public class Car extends Vehicles {
    
       List<String> Options = new ArrayList<>();
         
       
       public Car (String Make, String Model, int Year, Gearboxtype Gearbox, 
               Colour Colour, int Mileage, String VIN) {
           super(Make, Model, Year, Gearbox, Colour, Mileage, VIN);
        }
       
            
        
        public void Bodytype() {
        System.out.println();
        }
        
       


   }
    
        

    
    
