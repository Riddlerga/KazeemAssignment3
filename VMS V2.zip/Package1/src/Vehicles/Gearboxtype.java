
package Vehicles;

public enum Gearboxtype {
    
    Manual, Automatic
    
}
