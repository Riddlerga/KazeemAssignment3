
package Vehicles;

public abstract class Estate extends Car {
    
    public Estate(String Make, String Model, int Year, Gearboxtype Gearbox, Colour Colour, int Mileage, String VIN) {
        super(Make, Model, Year, Gearbox, Colour, Mileage, VIN);
    }
    
}
      
