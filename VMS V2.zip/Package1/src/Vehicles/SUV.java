
package Vehicles;

public abstract class SUV extends Car {
   
    
    public SUV(String Make, String Model, int Year, Gearboxtype Gearbox, Colour Colour, int Mileage, String VIN) {
        super(Make, Model, Year, Gearbox, Colour, Mileage, VIN);
    }
           @Override
    public void Bodytype(){
    System.out.println("SUV");
    }
    
}
      

