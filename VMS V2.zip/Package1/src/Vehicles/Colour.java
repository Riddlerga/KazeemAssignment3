
package Vehicles;

public enum Colour {
    
    Red, Yellow, Green, Blue, White, Black
    
}