
package Vehicles;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import uod.gla.menu.MenuBuilder;
import uod.gla.menu.MenuItem;
import uod.gla.util.CollectionUtils;
import uod.gla.util.Reader;

public class VehicleApp {
    
    private static List<Vehicles> VehicleList = new ArrayList<>();
    private static VehicleApp object = new VehicleApp();
    
    public static void main(String[] args) {
        System.out.println("Welcome to the Vehicle App");
        MenuItem create = new MenuItem ("1", "Create New Vehicle", object, "createVehicle");
        MenuItem list = new MenuItem("2", "Display All Vehicles", object, "listVehicles");
        MenuItem edit = new MenuItem("3", "Edit a Vehicle", object, "editVehicle");
        MenuItem manageVeh = new MenuItem("4", "Manage Vehicles", object, "manageVehicles");
        MenuBuilder.displayMenu(create, list, edit, manageVeh);
        System.out.println("Goodbye!");
    }
    
        public static void createVehicle() {
        MenuItem Car = new MenuItem("1", "New Car", object, "createCar");
        MenuItem Motorbike = new MenuItem("2", "New Motorbike", object, "createMotorbike");
        MenuBuilder.displayMenuOnceAndReturn("Please select an option...", Car, Motorbike);
    }
        
        public static void createCar() {
        MenuItem SUV = new MenuItem("1", "New SUV", object, "createCarSUV");
        MenuItem Saloon = new MenuItem("2", "New Saloon", object, "createCarSaloon");
        MenuItem Estate = new MenuItem("3", "New Estate", object, "createCarEstate");
        MenuItem Hatchback = new MenuItem("4", "New Hatchback", object, "createCarHatchback");
        MenuBuilder.displayMenuOnceAndReturn("Please select an option...", SUV, Saloon, Estate, Hatchback);
    }
        
        
        public static void createCarSUV() {
        String Make = Reader.readLine("Enter Vehilce Make: ");
        String Model = Reader.readLine("Enter Vehicle Model: ");
        int Year = Reader.readInt("Enter Vehicle Year: ");
        Gearboxtype Gearbox = Reader.readEnum("Select Gearbox type: ", Gearboxtype.class);
        Colour Colour = Reader.readEnum("Select Colour: ", Colour.class);
        int Mileage = Reader.readInt("Enter Mileage: ");
        String Vin = Reader.readLine("Enter Vin: ");
        Vehicles v = new SUV(Make, Model, Year, Gearbox, Colour, Mileage, Vin) {};
        VehicleList.add(v);
    }
        public static void createCarSaloon() {
        String Make = Reader.readLine("Enter Vehilce Make: ");
        String Model = Reader.readLine("Enter Vehicle Model: ");
        int Year = Reader.readInt("Enter Vehicle Year: ");
        Gearboxtype Gearbox = Reader.readEnum("Select Gearbox type: ", Gearboxtype.class);
        Colour Colour = Reader.readEnum("Select Colour: ", Colour.class);
        int Mileage = Reader.readInt("Enter Mileage: ");
        String Vin = Reader.readLine("Enter Vin: ");
        Vehicles v = new Saloon(Make, Model, Year, Gearbox, Colour, Mileage, Vin) {};
        VehicleList.add(v);
    }
        public static void createCarEstate() {
        String Make = Reader.readLine("Enter Vehilce Make: ");
        String Model = Reader.readLine("Enter Vehicle Model: ");
        int Year = Reader.readInt("Enter Vehicle Year: ");
        Gearboxtype Gearbox = Reader.readEnum("Select Gearbox type: ", Gearboxtype.class);
        Colour Colour = Reader.readEnum("Select Colour: ", Colour.class);
        int Mileage = Reader.readInt("Enter Mileage: ");
        String Vin = Reader.readLine("Enter Vin: ");
        Vehicles v = new Estate(Make, Model, Year, Gearbox, Colour, Mileage, Vin) {};
        VehicleList.add(v);
    }
        
        public static void createCarHatchback() {
        String Make = Reader.readLine("Enter Vehilce Make: ");
        String Model = Reader.readLine("Enter Vehicle Model: ");
        int Year = Reader.readInt("Enter Vehicle Year: ");
        Gearboxtype Gearbox = Reader.readEnum("Select Gearbox type: ", Gearboxtype.class);
        Colour Colour = Reader.readEnum("Select Colour: ", Colour.class);
        int Mileage = Reader.readInt("Enter Mileage: ");
        String Vin = Reader.readLine("Enter Vin: ");
        Vehicles v = new Hatchback(Make, Model, Year, Gearbox, Colour, Mileage, Vin) {};
        VehicleList.add(v);
    }
        
        public static void createMotorbike() {
        String Make = Reader.readLine("Enter Vehilce Make: ");
        String Model = Reader.readLine("Enter Vehicle Model: ");
        int Year = Reader.readInt("Enter Vehicle Year: ");
        Gearboxtype Gearbox = Reader.readEnum("Select Gearbox type: ", Gearboxtype.class);
        Colour Colour = Reader.readEnum("Select Colour: ", Colour.class);
        int Mileage = Reader.readInt("Enter Mileage: ");
        String Vin = Reader.readLine("Enter Vin: ");
        Vehicles v = new Motorbike(Make, Model, Year, Gearbox, Colour, Mileage, Vin);
        VehicleList.add(v);
    }
          public static void listVehicles() {
            Collections.sort(VehicleList);
            VehicleList.forEach((v) -> {
                System.out.println(v);
        });
        System.out.println();
        System.out.println(VehicleList.size() + " Vehicles displayed!");
    }  
          
        public static void editVehicle() {
        String key = Reader.readLine("Enter the details of a Vehilcle: ");
        Vehicles v = search(key);
        if (v == null) {
            System.out.println("No vehicle was found!");
            return;
        } else {
            System.out.println("Found the following vehicles...");
            System.out.println(v);
        }
        boolean edited = false;
        if (Reader.readBoolean("Do you want to change this vehicles Mileage? ")) {
            v.setMileage(Reader.readInt("Enter new Vehicle Mileage: "));
            edited = true;
        }
        
       
        if (edited) {
            System.out.println("One or more details have been successfully changed!");
        } else {
            System.out.println("No detail was changed");
        }
    }
           private static Vehicles search(String key) {
        Collection<Vehicles> results = CollectionUtils.search(key, VehicleList);
        if (results == null || results.isEmpty()) {
            return null;
        }
        return Reader.readObject("Please select a Vehicle from the list", results);
    }
           
        public static void manageVehicles() {
        MenuItem Vehicle = new MenuItem("1", "Choose Vehicle to add options", object, "optionsVeh");
        MenuItem Delopts = new MenuItem("2", "Choose Vehicle to remove options", object, "Delopts");
        MenuItem DeleteEntry = new MenuItem("3", "Delete Record", object, "Delete");
        MenuBuilder.displayMenuOnceAndReturn("Please select an option...", Vehicle, Delopts, DeleteEntry);
        }
        
        public static void optionsVeh() {
        String key = Reader.readLine("Seach for the vehicle to add the options: ");
        Vehicles v = search(key);
        if (v == null) {
            System.out.println("No vehicle was found!");
            return;
        } else {
            System.out.println("Found the following vehicles...");
            System.out.println(v);
        }
        boolean edited = false;
        if (Reader.readBoolean("Do you want to add a Sat Nav? ")) {
            v.AddSatNav((Car) v);
            edited = true;
        }
        if (Reader.readBoolean("Do you want to add Parking Sensor? ")) {
            v.AddParkingSensors((Car) v);
            edited = true;
        }
        if (Reader.readBoolean("Do you want to add a Tow Bar? ")) {
            v.AddTowBar((Car) v);
            edited = true;
        }
        if (Reader.readBoolean("Do you want to add a Roof Rack? ")) {
            v.AddRoofRack((Car) v);
            edited = true;
        }
        if (Reader.readBoolean("Do you want to add a Luggage Box? ")) {
            v.Addluggagebox((Motorbike) v);
            edited = true;
        }
        if (Reader.readBoolean("Do you want to add a Allwheel Drive? ")) {
            v.AddAWD((SUV) v);
            edited = true;
        }
        if (Reader.readBoolean("Do you want to add a Third Row Seat? ")) {
            v.Addtrs((Estate) v);
            edited = true;
        }
        if (edited) {
            System.out.println("One or more details have been successfully changed!");
        } else {
            System.out.println("No detail was changed");
        } 
        }

             public static void Delopts() {
        String key = Reader.readLine("Seach for the vehicle to remove the options: ");
        Vehicles v = search(key);
        if (v == null) {
            System.out.println("No vehicle was found!");
            return;
        } else {
            System.out.println("Found the following vehicles...");
            System.out.println(v);
        }
        boolean edited = false;
        if (Reader.readBoolean("Do you want to remove the luggage box? ")) {
            v.RemoveLuggageBox();
            edited = true;
        }
        if (edited) {
            System.out.println("One or more details have been successfully changed!");
        } else {
            System.out.println("No detail was changed");
        } 
        }
        
        public static void Delete() {
            System.out.println(VehicleList);
            String D = Reader.readName("Enter choose which record to delete (by VIN): ");
            System.out.println("The record to be deleted is: " + D);
        boolean remove = VehicleList.remove(D);
            System.out.println(remove);
        }
}
