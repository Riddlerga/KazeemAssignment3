package Vehicles;

public abstract class Saloon extends Car {
    
    public Saloon(String Make, String Model, int Year, Gearboxtype Gearbox, Colour Colour, int Mileage, String VIN) {
        super(Make, Model, Year, Gearbox, Colour, Mileage, VIN);
    }

      // this displays the body type
    
           @Override
    public void Bodytype(){
    System.out.println("Saloon");
    }
  

}