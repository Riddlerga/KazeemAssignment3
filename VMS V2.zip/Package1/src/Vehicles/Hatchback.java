package Vehicles;

public abstract class Hatchback extends Car {
    
    public Hatchback(String Make, String Model, int Year, Gearboxtype Gearbox, Colour Colour, int Mileage, String VIN) {
        super(Make, Model, Year, Gearbox, Colour, Mileage, VIN);
    }

    // this displays the body type
           @Override
    public void Bodytype(){
    System.out.println("Hatchback");
    }
    
    
}