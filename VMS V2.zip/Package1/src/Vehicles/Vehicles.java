package Vehicles;


public abstract class Vehicles extends Object implements Comparable<Vehicles>  {
    
    private final String Make;
    private final String Model;
    private final int Year;
    private final Gearboxtype Gearbox;// Using Enums
    private final Colour Colour;
    private int Mileage;
    private final String VIN;
    Car Sat_Nav;
    Car Parking_Sensors;
    Car Tow_Bar;
    Car Roof_Rack;
    Motorbike Luggage_Box;
    SUV AWD;
    Estate TRS;


    public Vehicles(String Make, String Model, int Year, Gearboxtype Gearbox, Colour Colour, int Mileage, String VIN) {
        this.Make = Make;
        this.Model = Model;
        this.Year = Year;
        this.Gearbox = Gearbox;// Using Enums
        this.Colour = Colour;
        this.Mileage = Mileage;
        this.VIN = VIN;
        
    }
// the section below allows the user to get information or set information on the vehicles
    
    public String getMake() {
        System.out.println("Make - " + Make);
        return Make;
    }

    public String getModel() {
        System.out.println("Model - " + Model);
        return Model;
    }

    public int getYear() {
        System.out.println("Year - " + Year);
        return Year;
    }

    public int getMileage() {
        System.out.println("Mileage - " + Mileage);
        return Mileage;
    }

    public void setMileage(int Mileage) {
        this.Mileage = Mileage;
    }

    public String getVIN() {
        System.out.println("VIN - " + VIN);
        return VIN;
    }
    
    public boolean hasSat_Nav() {
        return (Sat_Nav != null);
    }
    
    public boolean hasParking_Sensors() {
        return (Parking_Sensors != null);
    }
    
    public boolean hasTow_Bar() {
        return (Tow_Bar != null);
    } 
    
    public boolean hasRoof_Rack() {
        return (Roof_Rack != null);
    }
    
    public boolean hasLuggage_Box() {
        return (Luggage_Box != null);
    }
    
    public boolean hasAWD() {
        return (AWD != null);
    }
    
    public boolean hasTRS() {
        return (TRS != null);
    }
    
        public void AddSatNav (Car addSat_Nav){
        if (addSat_Nav.hasSat_Nav() || this.hasSat_Nav()) {
            System.out.println("This option has already been added");
            return;
        }
        this.Sat_Nav = addSat_Nav;
        addSat_Nav.Sat_Nav = (Car) this;
        System.out.println("Sat Nav Added");
        }
     
        public void AddParkingSensors (Car addParking_Sensors){
        if (addParking_Sensors.hasParking_Sensors() || this.hasParking_Sensors()) {
            System.out.println("This option has already been added");
            return;
        }
        this.Parking_Sensors = addParking_Sensors;
        addParking_Sensors.Parking_Sensors = (Car) this;
        System.out.println("Parking Sensors Added");
        }
        
        public void AddTowBar (Car addTow_Bar){
        if (addTow_Bar.hasTow_Bar() || this.hasTow_Bar()) {
            System.out.println("This option has already been added");
            return;
        }
        this.Tow_Bar = addTow_Bar;
        addTow_Bar.Tow_Bar = (Car) this;
        System.out.println("Tow Bar Added");
        }
        
        public void AddRoofRack (Car addRoof_Rack){
        if (addRoof_Rack.hasRoof_Rack() || this.hasRoof_Rack()) {
            System.out.println("This option has already been added");
            return;
        }
        this.Roof_Rack = addRoof_Rack;
        addRoof_Rack.Roof_Rack = (Car) this;
        System.out.println("Roof Rack Added");
        }
     
        public void Addluggagebox (Motorbike addLug_Box){
        if (addLug_Box.hasLuggage_Box() || this.hasLuggage_Box()) {
            System.out.println("This option has already been added");
            return;
        }
        this.Luggage_Box = addLug_Box;
        addLug_Box.Luggage_Box =  (Motorbike) this;
        System.out.println("Luggage Box Added");
        }
    
        public void RemoveLuggageBox() {
        if (this.Luggage_Box == null) {
            System.out.println("No Options added");
        } else {
            this.Luggage_Box.Luggage_Box = null;
            this.Luggage_Box = null;
            System.out.println("Luggage Box Removed");
        }
    }
        public void AddAWD (SUV addALLWHEELDRIVE){
        if (addALLWHEELDRIVE.hasAWD() || this.hasAWD()) {
            System.out.println("This option has already been added");
            return;
        }
        this.AWD = addALLWHEELDRIVE;
        addALLWHEELDRIVE.AWD = (SUV) this;
        System.out.println("All Wheel Drive has been Added");
        }   
        
        public void Addtrs (Estate addThirdRowSeat){
        if (addThirdRowSeat.hasTRS() || this.hasTRS()) {
            System.out.println("This option has already been added");
            return;
        }
        this.TRS = addThirdRowSeat;
        addThirdRowSeat.TRS = (Estate) this;
        System.out.println("Third Row Seat has been Added");
        } 
        
        
        
        
    
    @Override
    public int compareTo(Vehicles o) {
        if (!this.VIN.equals(o.VIN)) {
            // sort based on VIN
            return this.VIN.compareTo(o.VIN);
        } else if (this.Model.equals(o.Model)) {
            // sort based on model
            return this.Model.compareTo(o.Model);
        } else {
            return this.Year - o.Year;
        }
    }
    
        @Override
    public String toString() {
        // return the vehicles details
        return "\nVIN: " + getVIN() + "\nMake, Model, Year, Transmission, Colour, Mileage, Vin: " 
                + Make + ", " + Model + ", " + Year + ", " + Gearbox + ", " + Colour + ", " + Mileage + ", " + VIN;
        
    }

}
