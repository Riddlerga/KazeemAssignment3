package mortgagedecision;

import java.util.Scanner;

public class MortgageDecision {


    /* The main method should prompt for the following inputs: -
 * Gross annual salary, property value, deposit, interest rate 
 * and duration. The program should use these figures to 
 * determine if the mortgage application should be approved. 
 * The mortgage would be approved if the monthly repayment is 
* not more than 40% of the net monthly salary.
 */
 public static void main(String[] args) {

     Scanner Mortgage = new Scanner(System.in);

double gross_annual_salary;
double property_value;
double deposit;
double interest_rate;
double duration;
double taxed_allowance;
double twentytax ;
double thirtytax ;
double fortytax;
double totaltax;
double Salary_after_tax;

System.out.print("What is the customers annual salary)?: ");
gross_annual_salary = Mortgage.nextDouble();
System.out.print("What is the customers property value)?: ");
property_value = Mortgage.nextDouble();
System.out.print("What is the customers deposit?: ");
deposit = Mortgage.nextDouble();
System.out.print("What is the customers interest rate?: ");
interest_rate = Mortgage.nextDouble();
System.out.print("What is the customers duration?: ");
duration = Mortgage.nextDouble();


if (gross_annual_salary >= 125000) {
	taxed_allowance=0;
} else if (gross_annual_salary >= 100000) {
	taxed_allowance = (12500 - ((gross_annual_salary - 100000)*0.5));
} else {
	taxed_allowance = 12500;
}

if (gross_annual_salary >= 100000) {
    twentytax = ((50000 - taxed_allowance)*0.2);
    thirtytax = ((100000 - 50000)* 0.3);
    fortytax = ((gross_annual_salary - 100000) * 0.4);
    totaltax = twentytax + thirtytax + fortytax;
} else if (gross_annual_salary >= 50000) {
    twentytax = ((50000 - taxed_allowance)*0.2);
    thirtytax = ((100000 - 50000)* 0.3);
    totaltax = twentytax + thirtytax;
} else if  (gross_annual_salary >= 12500) {
        twentytax = ((gross_annual_salary - taxed_allowance)*0.2);
        totaltax = twentytax;
} else {
    totaltax = 0;
}

Salary_after_tax =  gross_annual_salary - totaltax; 

System.out.println("Salary after tax:  £" + Salary_after_tax);
}

public static double getNetSalary(double grossSalary) {
     return 0;
}
}
// code to calculate net annual salary [20 marks]
 //} 
 
 /* This method should calculate the monthly loan repayments
 * based on the values supplied.
 */
// public static double getMonthlyPayments(double propertyValue, 
//double deposit, double interest, int duration) { 
 //    return 0;
// code to calculate monthly loan payments [20 marks]
// }

//    public MortgageDecision() {
//        this.gross_annual_salary = 0;
//    }
 
//} // Up to 10 marks, if program compiles successfully.