/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mortgagedecision;

/**
 *
 * @author 070005313
 */
class Calc {
    
}
